# Catstagram

This is the starter project to help you learn how to use AJAX.

1. Clone this respository
   https://github.com/appacademy-starters/ajax-project-starter.
1. Follow the associated directions in the course.
1. See the cute kitties.
